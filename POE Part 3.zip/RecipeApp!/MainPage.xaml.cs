﻿using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.Geometry;
using Microsoft.Graphics.Canvas.UI.Xaml;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using System;
using System.Linq;
using System.Numerics;
using Windows.UI;

namespace RecipeApp
{
    public sealed partial class MainPage : Page
    {
        private RecipeManager recipeManager;

        public MainPage()
        {
            this.InitializeComponent();
            recipeManager = new RecipeManager();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.AddRecipe();
        }

        private void ListRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.ListRecipes();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.DisplayRecipe();
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.ScaleRecipe();
        }

        private void ResetRecipeQuantities_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.ResetRecipeQuantities();
        }

        private void ClearAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipeManager.ClearAllRecipes();
        }

        private void ShowPieChart_Click(object sender, RoutedEventArgs e)
        {
            // Logic to create a menu from selected recipes
            // This should update the data used to draw the pie chart
            pieChartCanvas.Invalidate(); // Redraw the canvas
        }

        private void Canvas_Draw(CanvasControl sender, CanvasDrawEventArgs args)
        {
            // Example data for pie chart
            float[] values = { 30, 20, 50 };
            Color[] colors = { Colors.Red, Colors.Green, Colors.Blue };

            float total = values.Sum();
            float startAngle = 0;

            for (int i = 0; i < values.Length; i++)
            {
                float sweepAngle = values[i] / total * 360;
                args.DrawingSession.FillGeometry(
                    CanvasGeometry.CreatePie(sender, new Vector2(150, 150), 100, startAngle, sweepAngle),
                    colors[i]);
                startAngle += sweepAngle;
            }
        }
    }
}
