﻿using System;
using System.Linq;
using Microsoft.Graphics.Canvas.Geometry;
using Microsoft.Graphics.Canvas.UI.Xaml;
using Windows.UI;
using Windows.UI.Xaml.Controls;
using System.Numerics;

namespace RecipeApp
{
    public sealed partial class MainPage : Page
    {
        private RecipeManager recipeManager;

        public MainPage()
        {
            this.InitializeComponent();
            recipeManager = new RecipeManager();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Logic to add a recipe
            recipeManager.AddRecipe();
        }

        private void ListRecipes_Click(object sender, RoutedEventArgs e)
        {
            // Logic to list recipes
            recipeManager.ListRecipes();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Logic to display a recipe
            recipeManager.DisplayRecipe();
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Logic to scale a recipe
            recipeManager.ScaleRecipe();
        }

        private void ResetRecipeQuantities_Click(object sender, RoutedEventArgs e)
        {
            // Logic to reset recipe quantities
            recipeManager.ResetRecipeQuantities();
        }

        private void ClearAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            // Logic to clear all recipes
            recipeManager.ClearAllRecipes();
        }

        private void ShowPieChart_Click(object sender, RoutedEventArgs e)
        {
            // Logic to create a menu and show pie chart
            CreateMenuAndShowPieChart();
        }

        private void CreateMenuAndShowPieChart()
        {
            // Logic to create a menu from selected recipes
            pieChartCanvas.Invalidate(); // Redraw the canvas
        }

        private void Canvas_Draw(CanvasControl sender, CanvasDrawEventArgs args)
        {
            // Example data for pie chart
            float[] values = { 30, 20, 50 };
            Color[] colors = { Colors.Red, Colors.Green, Colors.Blue };

            float total = values.Sum();
            float startAngle = 0;

            for (int i = 0; i < values.Length; i++)
            {
                float sweepAngle = values[i] / total * 360;
                args.DrawingSession.FillGeometry(
                    CanvasGeometry.CreatePie(sender, new Vector2(150, 150), 100, startAngle, sweepAngle),
                    colors[i]);
                startAngle += sweepAngle;
            }
        }
    }
}
