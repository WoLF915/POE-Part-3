﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace RecipeApp
{
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            this.InitializeComponent();
            rootFrame.Navigate(typeof(MainPage));
        }
    }
}
